(function(){
  var base = location.pathname.replace(/index\.html$/,'');
  if (!base.endsWith('/')) base += '/';
  window.App = window.App || {};
  window.App.config = window.App.config || {};
  window.App.config.routes = {};
  window.App.config.routes[base] = 'home';
  window.App.route = window.App.route || {new:{},old:{}};
  window.App.route.new = {url:base,page:'home'};
  window.App.route.old = {url:false,page:false};

  // The original site expects a server endpoint at "?cache=true". GitHub Pages is static,
  // so answer that request locally with the current page markup.
  var NativeXHR = window.XMLHttpRequest;
  window.XMLHttpRequest = function(){
    var xhr={readyState:0,status:0,responseText:'',onreadystatechange:null};
    xhr.open=function(method,url,async){xhr._url=url; xhr.readyState=1;};
    xhr.send=function(){
      xhr.readyState=4; xhr.status=200;
      var main=document.querySelector('#main');
      xhr.responseText=JSON.stringify({cache:{}, p404:{title:document.title,html:main?main.innerHTML:''}});
      setTimeout(function(){if(xhr.onreadystatechange) xhr.onreadystatechange();},0);
    };
    xhr.setRequestHeader=function(){};
    xhr.getResponseHeader=function(){return null;};
    return xhr;
  };

  // Let GitHub Pages handle real static pages instead of the original SPA router.
  document.addEventListener('click',function(e){
    var a=e.target.closest && e.target.closest('a[data-native]');
    if(a){e.stopImmediatePropagation();}
  },true);
})();