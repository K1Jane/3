# Яна / digitaldes — GitHub Pages

Загружай всё содержимое этой папки в корень ветки `main`. GitHub Pages: `Settings → Pages → Deploy from a branch → main → /(root)`.

Сайт: `https://k1jane.github.io/3/`
